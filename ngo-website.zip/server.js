
const express = require('express');
const bodyParser = require('body-parser');
const app = express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');

app.get('/', (req, res) => res.render('index'));
app.get('/about', (req, res) => res.render('about'));
app.get('/projects', (req, res) => res.render('projects'));
app.get('/donate', (req, res) => res.render('donate'));
app.get('/volunteer', (req, res) => res.render('volunteer'));
app.get('/contact', (req, res) => res.render('contact'));

app.post('/contact', (req, res) => {
  console.log(req.body);
  res.send("Thank you for contacting us!");
});

app.post('/donate', (req, res) => {
  console.log(req.body);
  res.send("Thank you for your donation!");
});

app.listen(3000, () => console.log("Server running on port 3000"));
